# Play board games in Linux Command-line

[![PyPI](https://img.shields.io/pypi/pyversions/Django.svg?style=plastic)]()
[![CocoaPods](https://img.shields.io/cocoapods/l/AFNetworking.svg?style=plastic)]()
[![PyPI](https://img.shields.io/pypi/status/Django.svg?style=plastic)]()
[![](https://img.shields.io/badge/version-1.0-blue.svg?style=plastic)]()

## Installation
Use `pip` to install this tool

    pip install comgames


## Usage

